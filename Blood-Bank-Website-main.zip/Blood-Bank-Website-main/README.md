# Blood-Bank-Website
Designed a management system for blood banks to handle donor data, inventory tracking, and blood requests.
